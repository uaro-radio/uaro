import board
import digitalio
import storage
import time

button = digitalio.DigitalInOut(board.GP14)
button.switch_to_input(pull=digitalio.Pull.UP)
time.sleep(0.1)

if not button.value:
    storage.enable_usb_drive()
else:
    storage.disable_usb_drive()

